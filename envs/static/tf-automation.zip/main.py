import os
import json
import tempfile
import shutil
import subprocess
from flask import Request, make_response
from googleapiclient import discovery
from oauth2client.client import GoogleCredentials
from google.oauth2 import service_account 
from googleapiclient.errors import HttpError
def automationTf(request: Request):
    data = request.get_json(silent=True) or {}
    action = data.get("action")
    print(f"Received action: {action}")

    try:
        instance      = "test-123432312"
        project_id    = "velvety-calling-458402-c1"
        backup_bucket = "db-backup-static"
        db_name       = "dolpin"
        env           = "static"
        print(f"Parsed env: instance={instance}, project_id={project_id}, bucket={backup_bucket}, db={db_name}, env={env}")
        KEY_PATH = "../../../../../../secrets/account.json"
        creds = service_account.Credentials.from_service_account_file(KEY_PATH)
        sql_service = discovery.build('sqladmin', 'v1', credentials=creds)
        print("Cloud SQL Admin client initialized")

        if action == "apply":
            import_body = { 'importContext': { 'fileType': 'SQL', 'uri': f"gs://{backup_bucket}/{env}/latest_dump.sql", 'databases': [db_name] } }
            print(f"Sending import request: {import_body}")
            sql_service.instances().import_(project=project_id, instance=instance, body=import_body).execute()
        elif action == "destroy":
            export_body = { 'exportContext': { 'fileType': 'SQL', 'uri': f"gs://{backup_bucket}/{env}/latest_dump.sql", 'databases': [db_name] } }
            print(f"Sending export request: {export_body}")
            sql_service.instances().export(project=project_id, instance=instance, body=export_body).execute()
        else:
            print("Invalid action received")
            return make_response("Invalid action", 400)

    except HttpError as e:
        print(f"HttpError: {e}")
        return make_response(f"Cloud SQL API error: {e}", 500)
    except Exception as e:
        print(f"Unexpected Exception: {e}")
        return make_response(f"Unexpected error: {e}", 500)

    return make_response("Good", 200)
